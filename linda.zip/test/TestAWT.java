// TestAWT.java
import javax.swing.*;
public class TestAWT {
    public static void main(String[] args) {
        JFrame f = new JFrame("Test");
        f.setSize(200, 100);
        f.setVisible(true);
    }
}
